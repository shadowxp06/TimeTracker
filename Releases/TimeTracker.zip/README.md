== Time Tracker ==

Requirements:
--
* SQL Server 2014 Instance or above
* .NET Framework 4.6.2

Extract to directory of your choosing and modify settings.ini, run program.

Restore DB Backup to SQL Server Instance